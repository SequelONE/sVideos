<?php
class sVideos extends xPDOSimpleObject {}