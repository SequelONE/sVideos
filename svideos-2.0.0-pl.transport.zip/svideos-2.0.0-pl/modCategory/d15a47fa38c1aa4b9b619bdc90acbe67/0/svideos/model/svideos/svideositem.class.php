<?php

/**
 * @package svideos
 */
class sVideosItem extends xPDOSimpleObject
{
}