<?php
class sVideosVideo extends xPDOSimpleObject {}