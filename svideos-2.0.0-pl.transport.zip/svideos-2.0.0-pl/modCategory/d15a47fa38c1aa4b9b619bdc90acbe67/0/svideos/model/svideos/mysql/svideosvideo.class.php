<?php
require_once (dirname(__DIR__) . '/svideosvideo.class.php');
class sVideosVideo_mysql extends sVideosVideo {}