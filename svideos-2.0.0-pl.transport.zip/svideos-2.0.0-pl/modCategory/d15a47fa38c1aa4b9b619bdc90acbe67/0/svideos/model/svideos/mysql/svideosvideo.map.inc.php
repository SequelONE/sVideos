<?php
$xpdo_meta_map['sVideosVideo']= array (
  'package' => 'svideos',
  'version' => '1.1',
  'table' => 'sv_videos',
  'extends' => 'xPDOSimpleObject',
  'tableMeta' => 
  array (
    'engine' => 'MyISAM',
  ),
  'fields' => 
  array (
    'category_id' => 0,
    'title' => NULL,
    'description' => NULL,
    'keywords' => NULL,
    'longtitle' => NULL,
    'content' => NULL,
    'image' => NULL,
    'code' => NULL,
    'alias' => NULL,
    'genre' => NULL,
    'channel' => NULL,
    'channel_name' => NULL,
    'keys' => NULL,
    'active' => 1,
    'createdby' => 1,
    'createdon' => 'CURRENT_TIMESTAMP',
    'editedon' => 'CURRENT_TIMESTAMP',
  ),
  'fieldMeta' => 
  array (
    'category_id' => 
    array (
      'dbtype' => 'int',
      'precision' => '11',
      'phptype' => 'integer',
      'null' => false,
      'default' => 0,
    ),
    'title' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '186',
      'phptype' => 'string',
      'null' => true,
    ),
    'description' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '301',
      'phptype' => 'string',
      'null' => true,
    ),
    'keywords' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '297',
      'phptype' => 'string',
      'null' => true,
    ),
    'longtitle' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '186',
      'phptype' => 'string',
      'null' => true,
    ),
    'content' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '9039',
      'phptype' => 'string',
      'null' => true,
    ),
    'image' => 
    array (
      'dbtype' => 'text',
      'phptype' => 'string',
      'null' => true,
    ),
    'code' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '11',
      'phptype' => 'string',
      'null' => true,
    ),
    'alias' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => true,
    ),
    'genre' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '255',
      'phptype' => 'string',
      'null' => false,
    ),
    'channel' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '100',
      'phptype' => 'string',
      'null' => true,
    ),
    'channel_name' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '100',
      'phptype' => 'string',
      'null' => true,
    ),
    'keys' => 
    array (
      'dbtype' => 'varchar',
      'precision' => '115',
      'phptype' => 'string',
      'null' => true,
    ),
    'active' => 
    array (
      'dbtype' => 'tinyint',
      'precision' => '1',
      'phptype' => 'integer',
      'null' => false,
      'default' => 1,
    ),
    'createdby' => 
    array (
      'dbtype' => 'tinyint',
      'precision' => '1',
      'phptype' => 'integer',
      'null' => false,
      'default' => 1,
    ),
    'createdon' => 
    array (
      'dbtype' => 'timestamp',
      'phptype' => 'timestamp',
      'null' => true,
      'default' => 'CURRENT_TIMESTAMP',
    ),
    'editedon' => 
    array (
      'dbtype' => 'timestamp',
      'phptype' => 'timestamp',
      'null' => false,
      'default' => 'CURRENT_TIMESTAMP',
      'extra' => 'on update current_timestamp',
    ),
  ),
  'aggregates' => 
  array (
    'sVideosCategories' => 
    array (
      'class' => 'sVideosCategories',
      'local' => 'category_id',
      'foreign' => 'id',
      'cardinality' => 'one',
      'owner' => 'foreign',
    ),
  ),
);
