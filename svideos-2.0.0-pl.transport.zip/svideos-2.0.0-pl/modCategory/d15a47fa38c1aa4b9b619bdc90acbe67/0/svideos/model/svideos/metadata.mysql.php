<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'sVideosCategories',
    1 => 'sVideosVideo',
  ),
);