<?php

$_lang['area_svideos_main'] = 'Main';

$_lang['setting_svideos_some_setting'] = 'Some setting';
$_lang['setting_svideos_some_setting_desc'] = 'This is description for some setting';