--------------------
sVideos
--------------------
Author: John Doe <john@doe.com>
--------------------

A basic Extra for MODx Revolution.