<?php
/** @var modX $modx */
switch ($modx->event->name) {

}