<?php
class sVideosCategories extends xPDOSimpleObject {}