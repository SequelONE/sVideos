<?php
require_once (dirname(__DIR__) . '/svideoscategories.class.php');
class sVideosCategories_mysql extends sVideosCategories {}